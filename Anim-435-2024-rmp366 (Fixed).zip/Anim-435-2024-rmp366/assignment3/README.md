# Anim-435-2024-14755860
This is the new description for the assignment 3! Hopefully this explains things well. 

This assignment was based off my last assignment (assignment 2) where it uses a UI and creates geometry such as a cube and/or sphere.

A bit of a description as to what the script does...
1. Create a sphere then creates a cube.
3. Adds a custom attribute to the selected object of your choosing.
4. Creates the UI. This includes a geometry section and custom Attribute section.
5. Runs the UI itself and boom done.